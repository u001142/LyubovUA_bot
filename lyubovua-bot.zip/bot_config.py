import os
from dotenv import load_dotenv

load_dotenv()

BOT_TOKEN = os.getenv("BOT_TOKEN")
WEBHOOK_SECRET = os.getenv("WEBHOOK_SECRET")
DOMAIN = os.getenv("DOMAIN")

WEBHOOK_URL = f"{DOMAIN}/{WEBHOOK_SECRET}"

LANGUAGES = {
    "uk": "Українська",
    "ru": "Русский",
    "en": "English"
}
