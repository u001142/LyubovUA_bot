# chat command handler (поки порожній)
