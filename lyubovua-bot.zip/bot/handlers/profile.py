# profile command handler (поки порожній)
