from .start import start_handler
from .profile import profile_handler
from .like import like_handler
from .chat import chat_handler

def setup_handlers(app):
    app.add_handler(start_handler)
    app.add_handler(profile_handler)
    app.add_handler(like_handler)
    app.add_handler(chat_handler)
