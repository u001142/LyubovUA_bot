# start command handler (поки порожній)
