# like command handler (поки порожній)
