from fastapi import FastAPI, Request
from telegram import Update
from telegram.ext import Application
from dotenv import load_dotenv
import os
from bot.handlers import setup_handlers

load_dotenv()

TOKEN = os.getenv("BOT_TOKEN")
WEBHOOK_SECRET = os.getenv("WEBHOOK_SECRET")

app = FastAPI()
application = Application.builder().token(TOKEN).build()
setup_handlers(application)

@app.post(f"/{WEBHOOK_SECRET}")
async def webhook(req: Request):
    data = await req.json()
    update = Update.de_json(data, application.bot)
    await application.process_update(update)
    return {"ok": True}
